document.getElementById("footer").innerHTML = `
<footer>
  <img src="/assets/logo.webp">
  <p>
    Desarrollado con <span>❤️</span> por <strong>Luis Jofré Pérez</strong> – Escuela Las Canteras, Copiapó 🌵 <br>
    Guardianes del Desierto © 2025 🦊
  </p>
</footer>
`;
document.getElementById("footer").innerHTML = `
<footer>
  <img src="/assets/logo.webp">
  <p>
    Desarrollado con <span>❤️</span> por <strong>Luis Jofré Pérez</strong> – Escuela Las Canteras, Copiapó 🌵 <br>
    Guardianes del Desierto © 2025 🦊
  </p>
</footer>
`;
